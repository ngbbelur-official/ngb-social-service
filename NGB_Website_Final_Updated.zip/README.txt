NGB website updated. Upload index.html to the root of the ngb-social-service GitHub repository and commit to main.
